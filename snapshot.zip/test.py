#!/usr/bin/python
"""
Script to perform some tests.
"""
#
# (C) Rob W.W. Hooft, 2003
#
# Distribute under the terms of the PSF license
#
__version__='$Id: test.py,v 1.19 2005/07/06 15:39:00 wikipedian Exp $'
#
import re,sys,wikipedia

for arg in sys.argv[1:]:
    arg = wikipedia.argHandler(arg, 'test')
    if arg:
        print "Unknown argument",arg
        wikipedia.stopme()
        sys.exit(1)

mysite = wikipedia.getSite()
if mysite.loggedin():
    print "Logged in (%s)" % repr(mysite)
else:
    print "Not logged in (%s)" % repr(mysite)

wikipedia.stopme()
